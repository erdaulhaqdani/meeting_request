<div class="col-xl-3 col-lg-4 col-md-6 col-sm-8 col-12 blog-sidebar">
	<div class="sidebar-container sidebar-search">
		<form action="/pages/pencarian" method="post">
			<input type="text" placeholder="Cari..." name="pencarian">
			<button><i class="fa fa-search" aria-hidden="true"></i></button>
		</form>
	</div> <!-- /.sidebar-search -->
	<div class="sidebar-container sidebar-categories">
		<h5 class="title">Kategori</h5>
		<ul>
			<li><a href="/pages/berita_grid">Berita</a></li>
			<li><a href="/pages/pengumuman_grid">Pengumuman</a></li>
			<li><a href="/pages/artikel_grid">Artikel</a></li>
			<li><a href="/pages/peristiwa_grid">Kilas Peristiwa</a></li>
			<li><a href="/pages/agenda_grid">Agenda</a></li>
		</ul>
	</div> <!-- /.sidebar-categories -->

</div> <!-- /.col- -->