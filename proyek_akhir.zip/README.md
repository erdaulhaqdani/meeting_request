# Landing Page KPKNL Bandung

## Daftar akun 
Daftar akun yang dapat digunakan untuk login APTB berdasarkan file sql terlampir

| Level    | Email                   | Password  |
| :------- | :---------------------- | :-------- |
| Customer | erdaulhaqdani@gmail.com | danihipya |
| Admin Landing Page | petugas@gmail.com | petugas |
| Petugas | loket@gmail.com | loket |

## Menjalankan aplikasi
Untuk menjalankan built-in server ketikkan:
```bash 
php spark serve
```
pada folder root dan nyalakan apache dan mysql pada web-server seperti XAMPP, database yang digunakan terdapat pada folder root dengan nama 'Kanwil.sql'

[CodeIgniter](https://codeigniter.com/user_guide/tutorial/index.html#getting-up-and-running)